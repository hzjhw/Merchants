/**
 * @description local
 * @namespace local
 * @author yongjin<zjut_wyj@163.com> 2014/12/13
 */
CONST.LIB_FORDER = 'lib';
CONST.DEBUG_SEAJS = false;
CONST.DEBUG_CONSOLE = false;
CONST.APP_VERSION = '201523523212';

/*CONST.HOST = 'http://m.11door.com';
CONST.API = 'http://m.11door.com';*/

/*
CONST.HOST= 'http://m.331.11door.com';
CONST.API= 'http://m.331.11door.com';
CONST.DOMAIN= 'http://m.331.11door.com';
CONST.PIC_URL= 'http://331.11door.com';*/
