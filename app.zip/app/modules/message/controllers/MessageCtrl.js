/**
 * @description MessageCtrl
 * @class MessageCtrl
 * @author yongjin<zjut_wyj@163.com> 2015/2/8
 */
define('MessageCtrl', [], function (require, exports, module) {
  var MessageCtrl;

  module.exports = MessageCtrl;
});